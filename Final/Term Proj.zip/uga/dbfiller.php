<!DOCTYPE html>
<html>
<body>
<h3 id='prog'></h3>
<p id='bdy'></p>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src='./dbAjax.js'></script>
</html>